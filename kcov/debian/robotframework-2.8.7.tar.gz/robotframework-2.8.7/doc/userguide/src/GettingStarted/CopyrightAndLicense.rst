Copyright and license
=====================

Robot Framework itself, test libraries and supporting tools distributed with it,
as well as this user guide and other provided documentation have the following
copyright statement.

.. include:: ../../../../COPYRIGHT.txt
   :literal:


