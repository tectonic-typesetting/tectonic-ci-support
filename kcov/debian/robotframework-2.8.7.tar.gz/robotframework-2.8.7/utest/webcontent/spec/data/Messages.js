window.messagesOutput = {};

window.messagesOutput["suite"] = [1,2,3,0,[],[0,0,142],[],[[4,0,1,0,[],[0,126,15,5],[[0,6,0,7,8,[1,128,1],[],[[129,2,9]]],[0,6,0,7,10,[1,129,1],[],[[130,2,10]]],[0,6,0,7,11,[1,130,1],[],[[131,3,13]]],[0,14,0,15,16,[1,131,1],[],[[132,2,17],[132,0,18]]],[0,6,0,7,19,[1,133,0],[],[[133,0,20],[133,1,21],[133,0,22]]],[0,6,0,7,23,[1,134,1],[],[[134,0,24],[134,0,25],[135,0,22]]],[0,14,0,15,26,[1,135,1],[],[[135,0,27],[136,2,28]]],[0,29,0,30,31,[0,136,4],[],[[140,4,5]]]]]],[],[1,0,1,0]];

window.messagesOutput["strings"] = [];

window.messagesOutput["strings"] = window.messagesOutput["strings"].concat(["*","*Messages","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/Messages.txt","*Messages.txt","*Test with messages","*HTML tagged content <a href='http://www.robotframework.org'>Robot Framework</a>","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*&lt;h1&gt;html&lt;/h1&gt;, HTML","*<h1>html</h1>","*infolevelmessage","*warning, WARN","*s1-t1-k3","*warning","*BuiltIn.Set Log Level","*<p>Sets the log threshold to the specified level and returns the old level.</p>","*TRACE","*Log level changed from INFO to TRACE","*Return: 'INFO'","*debugging, DEBUG","*Arguments: [ u'debugging' | u'DEBUG' ]","*debugging","*Return: None","*tracing, TRACE","*Arguments: [ u'tracing' | u'TRACE' ]","*tracing","*INFO","*Arguments: [ u'INFO' ]","*Log level changed from TRACE to INFO","*BuiltIn.Fail","*<p>Fails the test with the given message and optionally alters its tags.</p>","**HTML* HTML tagged content &lt;a href='http://www.robotframework.org'&gt;Robot Framework&lt;/a&gt;"]);

window.messagesOutput["generatedTimestamp"] = "20130604 13:23:26 GMT +03:00";

window.messagesOutput["errors"] = [[131,3,13,12]];

window.messagesOutput["stats"] = [[{"elapsed":"00:00:00","fail":1,"label":"Critical Tests","pass":0},{"elapsed":"00:00:00","fail":1,"label":"All Tests","pass":0}],[],[{"elapsed":"00:00:00","fail":1,"id":"s1","label":"Messages","name":"Messages","pass":0}]];

window.messagesOutput["generatedMillis"] = -696;

window.messagesOutput["baseMillis"] = 1370341406696;

window.settings = {"background":{"fail":"DeepPink"},"logURL":"log.html","reportURL":"report.html"};

