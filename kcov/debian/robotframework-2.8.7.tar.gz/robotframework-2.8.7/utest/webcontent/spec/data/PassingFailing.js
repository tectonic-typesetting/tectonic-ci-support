window.passingFailingOutput = {};

window.passingFailingOutput["suite"] = [1,2,3,0,[],[0,0,107],[],[[4,0,1,0,[],[1,94,7],[[0,5,0,6,7,[1,99,1],[],[[100,2,7]]]]],[8,0,1,0,[],[0,102,4,9],[[0,10,0,11,9,[0,104,1],[],[[105,4,9]]]]]],[],[2,1,2,1]];

window.passingFailingOutput["strings"] = [];

window.passingFailingOutput["strings"] = window.passingFailingOutput["strings"].concat(["*","*PassingFailing","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/teardownFailure/PassingFailing.txt","*teardownFailure/PassingFailing.txt","*Passing","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*passing","*Failing","*In test","*BuiltIn.Fail","*<p>Fails the test with the given message and optionally alters its tags.</p>"]);

window.passingFailingOutput["generatedTimestamp"] = "20130604 13:23:27 GMT +03:00";

window.passingFailingOutput["errors"] = [];

window.passingFailingOutput["stats"] = [[{"elapsed":"00:00:00","fail":1,"label":"Critical Tests","pass":1},{"elapsed":"00:00:00","fail":1,"label":"All Tests","pass":1}],[],[{"elapsed":"00:00:00","fail":1,"id":"s1","label":"PassingFailing","name":"PassingFailing","pass":1}]];

window.passingFailingOutput["generatedMillis"] = -22;

window.passingFailingOutput["baseMillis"] = 1370341407022;

window.settings = {"background":{"fail":"DeepPink"},"logURL":"log.html","reportURL":"report.html"};

