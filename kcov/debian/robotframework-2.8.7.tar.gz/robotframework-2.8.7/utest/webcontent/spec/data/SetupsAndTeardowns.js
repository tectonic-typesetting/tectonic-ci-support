window.setupsAndTeardownsOutput = {};

window.setupsAndTeardownsOutput["suite"] = [1,2,3,0,[],[1,0,156],[],[[4,0,1,0,[],[1,127,25],[[1,5,0,6,7,[1,131,1],[],[[132,2,7]]],[0,8,0,0,0,[1,138,8],[[0,9,0,10,0,[1,139,1],[],[]],[2,5,0,6,11,[1,145,1],[],[[146,2,11]]]],[]],[2,5,0,6,12,[1,150,1],[],[[151,2,12]]]]]],[[1,5,0,6,13,[1,117,7],[],[[124,2,13]]],[2,5,0,6,14,[1,154,2],[],[[156,2,14]]]],[1,1,1,1]];

window.setupsAndTeardownsOutput["strings"] = [];

window.setupsAndTeardownsOutput["strings"] = window.setupsAndTeardownsOutput["strings"].concat(["*","*SetupsAndTeardowns","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/SetupsAndTeardowns.txt","*SetupsAndTeardowns.txt","*Test","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*test setup","*Keyword with teardown","*BuiltIn.No Operation","*<p>Does absolutely nothing.</p>","*keyword teardown","*test teardown","*suite setup","*suite teardown"]);

window.setupsAndTeardownsOutput["generatedTimestamp"] = "20130604 13:23:26 GMT +03:00";

window.setupsAndTeardownsOutput["errors"] = [];

window.setupsAndTeardownsOutput["stats"] = [[{"elapsed":"00:00:00","fail":0,"label":"Critical Tests","pass":1},{"elapsed":"00:00:00","fail":0,"label":"All Tests","pass":1}],[],[{"elapsed":"00:00:00","fail":0,"id":"s1","label":"SetupsAndTeardowns","name":"SetupsAndTeardowns","pass":1}]];

window.setupsAndTeardownsOutput["generatedMillis"] = -452;

window.setupsAndTeardownsOutput["baseMillis"] = 1370341406452;

window.settings = {"background":{"fail":"DeepPink"},"logURL":"log.html","reportURL":"report.html"};

