window.suiteOutput = {};

window.suiteOutput["suite"] = [1,2,3,4,[5,6],[1,0,254],[],[[7,8,1,9,[10,11],[1,135,115],[[0,12,0,13,14,[1,138,101],[],[[239,2,15]]],[3,16,0,0,0,[1,240,6],[[4,17,0,0,0,[1,240,3],[[0,18,0,0,19,[1,241,2],[[0,20,0,21,22,[1,242,1],[],[[243,2,23]]]],[]]],[]],[4,24,0,0,0,[1,243,3],[[0,18,0,0,19,[1,244,2],[[0,20,0,21,22,[1,245,1],[],[[246,2,25]]]],[]]],[]]],[]]]]],[],[1,1,1,1]];

window.suiteOutput["strings"] = [];

window.suiteOutput["strings"] = window.suiteOutput["strings"].concat(["*","*Suite","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/Suite.txt","*Suite.txt","*<p>suite doc</p>","*meta","*<p>data</p>","*Test","*1 second","*<p>test doc</p>","*tag1","*tag2","*BuiltIn.Sleep","*<p>Pauses the test executed for the given time.</p>","*0.1 seconds","*Slept 100 milliseconds","*${i} IN RANGE [ 2 ]","*${i} = 0","*my keyword","*${i}","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*index is ${index}","*index is 0","*${i} = 1","*index is 1"]);

window.suiteOutput["generatedTimestamp"] = "20130604 13:23:26 GMT +03:00";

window.suiteOutput["errors"] = [];

window.suiteOutput["stats"] = [[{"elapsed":"00:00:00","fail":0,"label":"Critical Tests","pass":1},{"elapsed":"00:00:00","fail":0,"label":"All Tests","pass":1}],[{"elapsed":"00:00:00","fail":0,"label":"tag1","pass":1},{"elapsed":"00:00:00","fail":0,"label":"tag2","pass":1}],[{"elapsed":"00:00:00","fail":0,"id":"s1","label":"Suite","name":"Suite","pass":1}]];

window.suiteOutput["generatedMillis"] = -110;

window.suiteOutput["baseMillis"] = 1370341406110;

window.settings = {"background":{"fail":"DeepPink"},"logURL":"log.html","reportURL":"report.html"};

