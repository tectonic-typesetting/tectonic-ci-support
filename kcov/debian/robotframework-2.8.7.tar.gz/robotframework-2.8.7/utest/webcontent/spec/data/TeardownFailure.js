window.teardownFailureOutput = {};

window.teardownFailureOutput["suite"] = [1,2,1,0,[],[0,0,90,3],[[4,5,6,0,[],[0,74,13],[],[[7,0,1,0,[],[0,79,3,8],[[0,9,0,10,11,[1,81,0],[],[[81,2,11]]]]],[12,0,1,0,[],[0,82,3,13],[[0,14,0,15,16,[0,84,1],[],[[84,4,16]]]]]],[],[2,0,2,0]]],[],[[2,14,0,15,0,[0,89,1,17],[],[[90,4,17]]]],[2,0,2,0]];

window.teardownFailureOutput["strings"] = [];

window.teardownFailureOutput["strings"] = window.teardownFailureOutput["strings"].concat(["*","*teardownFailure","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/teardownFailure","*Suite teardown failed:\nAssertionError","*PassingFailing","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/teardownFailure/PassingFailing.txt","*teardownFailure/PassingFailing.txt","*Passing","*Parent suite teardown failed:\nAssertionError","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*passing","*Failing","*In test\n\nAlso parent suite teardown failed:\nAssertionError","*BuiltIn.Fail","*<p>Fails the test with the given message and optionally alters its tags.</p>","*In test","*AssertionError"]);

window.teardownFailureOutput["generatedTimestamp"] = "20130604 13:23:26 GMT +03:00";

window.teardownFailureOutput["errors"] = [];

window.teardownFailureOutput["stats"] = [[{"elapsed":"00:00:00","fail":2,"label":"Critical Tests","pass":0},{"elapsed":"00:00:00","fail":2,"label":"All Tests","pass":0}],[],[{"elapsed":"00:00:00","fail":2,"id":"s1","label":"teardownFailure","name":"teardownFailure","pass":0},{"elapsed":"00:00:00","fail":2,"id":"s1-s1","label":"teardownFailure.PassingFailing","name":"PassingFailing","pass":0}]];

window.teardownFailureOutput["generatedMillis"] = -887;

window.teardownFailureOutput["baseMillis"] = 1370341406887;

window.settings = {"background":{"fail":"DeepPink"},"logURL":"log.html","reportURL":"report.html"};

