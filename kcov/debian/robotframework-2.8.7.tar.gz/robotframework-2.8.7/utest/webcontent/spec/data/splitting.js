window.splittingOutput = {};

window.splittingOutput["suite"] = [1,2,3,0,[],[0,0,288],[[4,5,6,0,[],[0,65,18],[],[[7,0,1,0,[],[0,70,12,8],1]],[],[1,0,1,0]],[10,11,12,0,[],[1,84,16],[],[[13,0,1,0,[],[1,91,6],2]],[[1,14,0,15,16,[1,90,0],3,[[90,2,16]]],[2,14,0,15,17,[1,99,0],4,[[99,2,17]]]],[1,1,1,1]],[18,19,20,21,[22,23],[1,101,121],[],[[13,24,1,25,[26,27],[1,109,112],5]],[],[1,1,1,1]],[28,29,28,0,[],[0,224,22,30],[[31,32,33,0,[],[0,230,13],[],[[34,0,1,0,[],[0,235,2,35],6],[36,0,1,0,[],[0,238,4,37],7]],[],[2,0,2,0]]],[],[[2,38,0,39,0,[0,245,0,40],8,[[245,4,40]]]],[2,0,2,0]],[41,42,43,0,[],[1,248,37],[],[[44,0,1,0,[],[1,262,11],9],[45,0,1,0,[],[1,274,3],10],[46,0,1,0,[],[1,278,3],11],[47,0,1,0,[],[1,281,2],12]],[],[4,4,4,4]]],[],[],[9,6,9,6]];

window.splittingOutput["strings"] = [];

window.splittingOutput["strings"] = window.splittingOutput["strings"].concat(["*","*Data","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data","*data","*Messages","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/Messages.txt","*Messages.txt","*Test with messages","*HTML tagged content <a href='http://www.robotframework.org'>Robot Framework</a>","*s1-s1-t1-k3","*SetupsAndTeardowns","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/SetupsAndTeardowns.txt","*SetupsAndTeardowns.txt","*Test","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*suite setup","*suite teardown","*Suite","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/Suite.txt","*Suite.txt","*<p>suite doc</p>","*meta","*<p>data</p>","*1 second","*<p>test doc</p>","*tag1","*tag2","*teardownFailure","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/teardownFailure","*Suite teardown failed:\nAssertionError","*PassingFailing","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/teardownFailure/PassingFailing.txt","*teardownFailure/PassingFailing.txt","*Passing","*Parent suite teardown failed:\nAssertionError","*Failing","*In test\n\nAlso parent suite teardown failed:\nAssertionError","*BuiltIn.Fail","*<p>Fails the test with the given message and optionally alters its tags.</p>","*AssertionError","*TestsAndKeywords","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/TestsAndKeywords.txt","*TestsAndKeywords.txt","*Test 1","*Test 2","*Test 3","*Test 4","*warning"]);

window.splittingOutput["generatedTimestamp"] = "20130604 13:23:28 GMT +03:00";

window.splittingOutput["errors"] = [[74,3,48,9]];

window.splittingOutput["stats"] = [[{"elapsed":"00:00:00","fail":3,"label":"Critical Tests","pass":6},{"elapsed":"00:00:00","fail":3,"label":"All Tests","pass":6}],[{"elapsed":"00:00:00","fail":0,"label":"tag1","pass":1},{"elapsed":"00:00:00","fail":0,"label":"tag2","pass":1}],[{"elapsed":"00:00:00","fail":3,"id":"s1","label":"Data","name":"Data","pass":6},{"elapsed":"00:00:00","fail":1,"id":"s1-s1","label":"Data.Messages","name":"Messages","pass":0},{"elapsed":"00:00:00","fail":0,"id":"s1-s2","label":"Data.SetupsAndTeardowns","name":"SetupsAndTeardowns","pass":1},{"elapsed":"00:00:00","fail":0,"id":"s1-s3","label":"Data.Suite","name":"Suite","pass":1},{"elapsed":"00:00:00","fail":2,"id":"s1-s4","label":"Data.teardownFailure","name":"teardownFailure","pass":0},{"elapsed":"00:00:00","fail":2,"id":"s1-s4-s1","label":"Data.teardownFailure.PassingFailing","name":"PassingFailing","pass":0},{"elapsed":"00:00:00","fail":0,"id":"s1-s5","label":"Data.TestsAndKeywords","name":"TestsAndKeywords","pass":4}]];

window.splittingOutput["generatedMillis"] = 117;

window.splittingOutput["baseMillis"] = 1370341407883;

window.settings = {"background":{"fail":"DeepPink"},"logURL":"log.html","reportURL":"report.html"};

window.splittingOutputKeywords0 = [[0,1,0,2,3,[1,71,1],[],[[72,2,4]]],[0,1,0,2,5,[1,72,1],[],[[73,2,5]]],[0,1,0,2,6,[1,73,1],[],[[74,3,7]]],[0,8,0,9,10,[1,75,1],[],[[76,2,11],[76,0,12]]],[0,1,0,2,13,[1,76,1],[],[[77,0,14],[77,1,15],[77,0,16]]],[0,1,0,2,17,[1,78,0],[],[[78,0,18],[78,0,19],[78,0,16]]],[0,8,0,9,20,[1,79,1],[],[[79,0,21],[80,2,22]]],[0,23,0,24,25,[0,80,1],[],[[81,4,26]]]];
window.splittingOutputStrings0 = ["*","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*&lt;h1&gt;html&lt;/h1&gt;, HTML","*<h1>html</h1>","*infolevelmessage","*warning, WARN","*warning","*BuiltIn.Set Log Level","*<p>Sets the log threshold to the specified level and returns the old level.</p>","*TRACE","*Log level changed from INFO to TRACE","*Return: 'INFO'","*debugging, DEBUG","*Arguments: [ u'debugging' | u'DEBUG' ]","*debugging","*Return: None","*tracing, TRACE","*Arguments: [ u'tracing' | u'TRACE' ]","*tracing","*INFO","*Arguments: [ u'INFO' ]","*Log level changed from TRACE to INFO","*BuiltIn.Fail","*<p>Fails the test with the given message and optionally alters its tags.</p>","**HTML* HTML tagged content &lt;a href='http://www.robotframework.org'&gt;Robot Framework&lt;/a&gt;","*HTML tagged content <a href='http://www.robotframework.org'>Robot Framework</a>"];
window.splittingOutputKeywords1 = [[1,1,0,2,3,[1,92,1],[],[[93,2,3]]],[0,4,0,0,0,[1,93,3],[[0,5,0,6,0,[1,94,1],[],[]],[2,1,0,2,7,[1,95,1],[],[[96,2,7]]]],[]],[2,1,0,2,8,[1,97,0],[],[[97,2,8]]]];
window.splittingOutputStrings1 = ["*","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*test setup","*Keyword with teardown","*BuiltIn.No Operation","*<p>Does absolutely nothing.</p>","*keyword teardown","*test teardown"];
window.splittingOutputKeywords2 = [];
window.splittingOutputStrings2 = ["*"];
window.splittingOutputKeywords3 = [];
window.splittingOutputStrings3 = ["*"];
window.splittingOutputKeywords4 = [[0,1,0,2,3,[1,111,102],[],[[213,2,4]]],[3,5,0,0,0,[1,214,6],[[4,6,0,0,0,[1,214,3],[[0,7,0,0,8,[1,214,3],[[0,9,0,10,11,[1,216,1],[],[[217,2,12]]]],[]]],[]],[4,13,0,0,0,[1,217,3],[[0,7,0,0,8,[1,218,2],[[0,9,0,10,11,[1,219,1],[],[[220,2,14]]]],[]]],[]]],[]]];
window.splittingOutputStrings4 = ["*","*BuiltIn.Sleep","*<p>Pauses the test executed for the given time.</p>","*0.1 seconds","*Slept 100 milliseconds","*${i} IN RANGE [ 2 ]","*${i} = 0","*my keyword","*${i}","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*index is ${index}","*index is 0","*${i} = 1","*index is 1"];
window.splittingOutputKeywords5 = [[0,1,0,2,3,[1,236,1],[],[[237,2,3]]]];
window.splittingOutputStrings5 = ["*","*BuiltIn.Log","*<p>Logs the given message with the given level.</p>","*passing"];
window.splittingOutputKeywords6 = [[0,1,0,2,3,[0,240,1],[],[[241,4,3]]]];
window.splittingOutputStrings6 = ["*","*BuiltIn.Fail","*<p>Fails the test with the given message and optionally alters its tags.</p>","*In test"];
window.splittingOutputKeywords7 = [];
window.splittingOutputStrings7 = ["*"];
window.splittingOutputKeywords8 = [[0,1,0,0,0,[1,264,2],[[0,2,0,3,0,[1,265,1],[],[]]],[]],[0,4,0,0,0,[1,266,2],[[0,2,0,3,0,[1,267,1],[],[]]],[]],[0,5,0,0,0,[1,268,2],[[0,2,0,3,0,[1,269,1],[],[]]],[]],[0,6,0,0,0,[1,271,2],[[0,2,0,3,0,[1,272,1],[],[]]],[]]];
window.splittingOutputStrings8 = ["*","*kw1","*BuiltIn.No Operation","*<p>Does absolutely nothing.</p>","*kw2","*kw3","*kw4"];
window.splittingOutputKeywords9 = [[0,1,0,2,0,[1,276,0],[],[]]];
window.splittingOutputStrings9 = ["*","*BuiltIn.No Operation","*<p>Does absolutely nothing.</p>"];
window.splittingOutputKeywords10 = [[0,1,0,2,0,[1,280,0],[],[]]];
window.splittingOutputStrings10 = ["*","*BuiltIn.No Operation","*<p>Does absolutely nothing.</p>"];
window.splittingOutputKeywords11 = [[0,1,0,2,0,[1,283,0],[],[]]];
window.splittingOutputStrings11 = ["*","*BuiltIn.No Operation","*<p>Does absolutely nothing.</p>"];
