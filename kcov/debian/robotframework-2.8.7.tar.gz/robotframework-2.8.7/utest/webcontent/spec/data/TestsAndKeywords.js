window.testsAndKeywordsOutput = {};

window.testsAndKeywordsOutput["suite"] = [1,2,3,0,[],[1,0,103],[],[[4,0,1,0,[],[1,81,12],[[0,5,0,0,0,[1,82,2],[[0,6,0,7,0,[1,83,1],[],[]]],[]],[0,8,0,0,0,[1,85,2],[[0,6,0,7,0,[1,86,0],[],[]]],[]],[0,9,0,0,0,[1,88,3],[[0,6,0,7,0,[1,90,1],[],[]]],[]],[0,10,0,0,0,[1,91,2],[[0,6,0,7,0,[1,92,1],[],[]]],[]]]],[11,0,1,0,[],[1,94,3],[[0,6,0,7,0,[1,96,0],[],[]]]],[12,0,1,0,[],[1,97,2],[[0,6,0,7,0,[1,99,0],[],[]]]],[13,0,1,0,[],[1,100,2],[[0,6,0,7,0,[1,101,1],[],[]]]]],[],[4,4,4,4]];

window.testsAndKeywordsOutput["strings"] = [];

window.testsAndKeywordsOutput["strings"] = window.testsAndKeywordsOutput["strings"].concat(["*","*TestsAndKeywords","*/Users/zesus/Documents/workspace/robotframework/utest/webcontent/spec/data/TestsAndKeywords.txt","*TestsAndKeywords.txt","*Test 1","*kw1","*BuiltIn.No Operation","*<p>Does absolutely nothing.</p>","*kw2","*kw3","*kw4","*Test 2","*Test 3","*Test 4"]);

window.testsAndKeywordsOutput["generatedTimestamp"] = "20130604 13:23:27 GMT +03:00";

window.testsAndKeywordsOutput["errors"] = [];

window.testsAndKeywordsOutput["stats"] = [[{"elapsed":"00:00:00","fail":0,"label":"Critical Tests","pass":4},{"elapsed":"00:00:00","fail":0,"label":"All Tests","pass":4}],[],[{"elapsed":"00:00:00","fail":0,"id":"s1","label":"TestsAndKeywords","name":"TestsAndKeywords","pass":4}]];

window.testsAndKeywordsOutput["generatedMillis"] = -170;

window.testsAndKeywordsOutput["baseMillis"] = 1370341407170;

window.settings = {"background":{"fail":"DeepPink"},"logURL":"log.html","reportURL":"report.html"};

