MY_VARIABLE = "An example string"
